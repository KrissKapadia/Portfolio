import React, { useEffect, useRef, useState } from 'react';
import './Skills.css';

const Skills = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  const skillCategories = [
    {
      icon: '💻',
      title: 'Programming & Frameworks',
      skills: [
        'JavaScript', 'Java', 'Python', 'C++', 'C#', 'SQL',
        'HTML5', 'CSS3', 'React.js', 'Next.js', 'Node.js',
        'Express.js', 'Vite.js', 'Tailwind CSS'
      ]
    },
    {
      icon: '☁️',
      title: 'Database, Cloud & DevOps',
      skills: [
        'MySQL', 'PostgreSQL', 'MongoDB', 'Oracle', 'AWS EC2',
        'AWS S3', 'DynamoDB', 'Azure', 'Docker', 'Git',
        'GitHub', 'CI/CD', 'GitHub Actions', 'Jenkins',
        'PowerShell', 'Jira', 'Postman'
      ]
    },
    {
      icon: '📊',
      title: 'Data, Testing & Methodologies',
      skills: [
        'NumPy', 'Pandas', 'Matplotlib', 'DSA', 'Jest',
        'Mocha', 'JUnit', 'PyTest', 'Agile', 'Scrum', 'Kanban'
      ]
    },
    {
      icon: '🤝',
      title: 'Soft Skills',
      skills: [
        'Problem-Solving', 'Collaboration', 'Communication',
        'Adaptability', 'Leadership', 'Teaching'
      ]
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
      }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        // eslint-disable-next-line react-hooks/exhaustive-deps
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section id="skills" className="section" ref={sectionRef}>
      <div className="container">
        <h2 className="section-title">Skills & Technologies</h2>
        <div className="skills-grid">
          {skillCategories.map((category, categoryIndex) => (
            <div
              key={categoryIndex}
              className={`skill-category ${isVisible ? 'fade-in visible' : 'fade-in'}`}
              style={{ animationDelay: `${categoryIndex * 0.2}s` }}
            >
              <div className="skill-icon">{category.icon}</div>
              <h3>{category.title}</h3>
              <div className="skill-tags">
                {category.skills.map((skill, skillIndex) => (
                  <span
                    key={skillIndex}
                    className="skill-tag"
                    style={{ animationDelay: `${(categoryIndex * 0.2) + (skillIndex * 0.1)}s` }}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;