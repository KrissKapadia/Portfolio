import React, { useState, useRef, useEffect } from 'react';
import emailjs from 'emailjs-com';
import { FaGithub, FaLinkedin } from 'react-icons/fa';
import './Contact.css';

const Contact = () => {
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState({ text: '', type: '' });
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setIsVisible(true); },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    return () => { if (sectionRef.current) observer.unobserve(sectionRef.current); };
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const showMessage = (text, type) => {
    setMessage({ text, type });
    setTimeout(() => setMessage({ text: '', type: '' }), 5000);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await emailjs.send(
        'service_sj13hcd',
        'template_1jw2lep',
        formData,
        'l7UdCf_Wx6gVUTfEs'
      );
      showMessage('Message sent successfully!', 'success');
      setFormData({ name: '', email: '', subject: '', message: '' });
    } catch (error) {
      console.error(error);
      showMessage('Failed to send message. Please try again.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className={`contact-section ${isVisible ? 'fade-in visible' : 'fade-in'}`}
    >
      {message.text && (
        <div className={`toast ${message.type === 'success' ? 'success' : 'error'}`}>
          {message.text}
        </div>
      )}

      <div className="container">
        <h2 className="title">Get In Touch</h2>
        <p className="description">
          I'm always open to new opportunities and collaborations. You can fill out the form below, or reach me directly via:
        </p>

        <div className="contact-info">
          <p><strong>Email:</strong> <a href="mailto:kapadiakriss05@gmail.com">kapadiakriss05@gmail.com</a></p>
          <p><strong>Phone:</strong> <a href="tel:+16475274303">+1 (647) 527-4303</a></p>
          <div className="social-icons">
            <a href="https://github.com/KrissKapadia" target="_blank" rel="noopener noreferrer"><FaGithub /></a>
            <a href="https://www.linkedin.com/in/kriss-kapadia-700315248/" target="_blank" rel="noopener noreferrer"><FaLinkedin /></a>
          </div>
        </div>

        <div className="form-wrapper">
          <form onSubmit={handleSubmit} className="form">
            <input type="text" name="name" value={formData.name} onChange={handleInputChange} placeholder="Name" required />
            <input type="email" name="email" value={formData.email} onChange={handleInputChange} placeholder="Email" required />
            <input type="text" name="subject" value={formData.subject} onChange={handleInputChange} placeholder="Subject" required />
            <textarea name="message" value={formData.message} onChange={handleInputChange} placeholder="Message" rows="5" required></textarea>
            <button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Sending...' : 'Send Message'}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};

export default Contact;
