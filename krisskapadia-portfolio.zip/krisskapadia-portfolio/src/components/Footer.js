import React from 'react';
import './Footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="footer">
      <div className="container">
        <p>&copy; {currentYear} Kriss Alpesh Kapadia. All rights reserved.</p>
        <p>Built with passion and modern React technologies.</p>
      </div>
    </footer>
  );
};

export default Footer;