import React, { useState, useEffect } from 'react';
import './Hero.css'; // Import the CSS file
import profilePhoto from '../assets/profile.jpg'; // relative path from Hero.js

const Hero = () => {
  const [displayText, setDisplayText] = useState('');
  const [typingDone, setTypingDone] = useState(false);
  const fullText = 'Kriss Alpesh Kapadia';

  useEffect(() => {
    let index = 0;
    const timer = setInterval(() => {
      if (index < fullText.length) {
        setDisplayText(fullText.slice(0, index + 1));
        index++;
      } else {
        clearInterval(timer);
        setTypingDone(true);
      }
    }, 100);

    return () => clearInterval(timer);
  }, []);

  const handleNavClick = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offsetTop = element.offsetTop - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="hero">
      <div className="hero-container">
        <div className="hero-content">
          <h1 className="hero-title">
            {displayText}
            {!typingDone && <span className="cursor">|</span>}
          </h1>

          <div className="hero-description">
            I am a passionate and enthusiastic student who loves learning and building projects. 
            I enjoy exploring software testing, web designing, and data analytics, and I thrive on solving real-world problems with technology.
          </div>

          <div className="cta-buttons">
            <button 
              onClick={() => handleNavClick('projects')} 
              className="btn btn-primary"
            >
              View My Work
            </button>
            <button 
              onClick={() => handleNavClick('contact')} 
              className="btn btn-secondary"
            >
              Get In Touch
            </button>
          </div>
        </div>
        
        <div className="hero-image">
          <div className="profile-pic-container">
            <img 
              src={profilePhoto} 
              alt="Kriss Alpesh Kapadia" 
              className="profile-photo"
              onError={(e) => {
                e.target.style.display = 'none';
                e.target.nextSibling.style.display = 'flex';
              }}
            />
            <div className="profile-placeholder" style={{ display: 'none' }}>
              KAK
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
