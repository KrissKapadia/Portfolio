import React, { useEffect, useRef, useState } from 'react';
import './Experience.css';

const Experience = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  const experiences = [
    {
      title: 'Lead Educator',
      company: 'Student Scholars',
      period: 'Sep 2024 - Present',
      summary: "Designed and delivered a project-based curriculum teaching Python, Robotics, and Web Designing to over 50 students. Mentored a team of junior educators, improving lesson quality and collaborative teaching practices. Developed hands-on projects and coding challenges to enhance practical skills, critical thinking, and problem-solving. Organized workshops and competitions to engage students and foster real-world application of technical concepts.",
      skills: ['Leadership & Team Management', 'Student Engagement & Communication', 'Mentoring & Coaching']
    },
    {
      title: 'QA Tester',
      company: 'Freelance',
      period: 'Aug 2025 - Present',
      summary: "Executed comprehensive functional, regression, and cross-browser testing to ensure flawless user experiences. Collaborated with developers to identify and log critical bugs in Jira, accelerating the resolution process. Designed and implemented detailed test cases and checklists, improving test coverage and efficiency. Actively contributed to process improvements and recommended solutions to enhance software quality and performance.",
      skills: ['Quality Assurance & Software Testing', 'Attention to Detail & Analytical Thinking', 'Team Collaboration', 'Cross-Browser & Cross-Device Testing']
    },
    {
        title: 'Store Associate/IT Support Specialist',
        company: 'Funland Indoor Playground',
        period: 'Jan 2024 - Present',
        summary: "Provided technical support for point-of-sale systems, kiosks, and network devices to ensure smooth daily operations. Assisted customers with inquiries and troubleshooting, delivering high-quality service while maintaining operational efficiency. Additionally, I was the in-charge for managing inventory and operational software, quickly resolving system issues and implementing process improvements to enhance overall workflow.",
        skills: ['Technical Support & Troubleshooting','Process Improvement & Workflow Optimization','Customer Service & Communication',]
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setIsVisible(true);
      },
      { threshold: 0.2 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => {
      if (sectionRef.current) observer.unobserve(sectionRef.current);
    };
  }, []);

  return (
    <section id="experience" ref={sectionRef} className="experience-section">
      <div className="container">
        {/* Section title with hover underline */}
        <h2 className="section-title hover-underline">Professional Experience</h2>

        <div className={`experience-cards-container ${isVisible ? 'visible' : ''}`}>
          {experiences.map((exp, idx) => (
            <div key={idx} className="experience-card">
              <div className="card-header">
                <h3>{exp.title}</h3>
                <span className="period">{exp.period}</span>
              </div>
              <p className="company">{exp.company}</p>
              <p className="summary">{exp.summary}</p>
              <div className="skills-container">
                {exp.skills.map((skill, i) => (
                  <span key={i} className="skill-tag">{skill}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;
