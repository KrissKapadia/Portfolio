import React, { useEffect, useRef, useState } from 'react';
import './Projects.css';

const Projects = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef(null);

  const projects = [
    {
      title: 'Patient Data Dashboard',
      tech: 'Power BI • Python • SQL • DAX',
      description: 'Built an interactive patient management dashboard in Power BI using DAX, with real-time filtering, automated data refresh, and visualizations for medical history, expenses, and medication records. Integrated SQL database and Python ETL scripts for accurate data synchronization.',
      links: [
        { text: 'GitHub', url: 'https://github.com/KrissKapadia/Patient-Dashboard' }
      ]
    },
    {
      title: 'Fragment Cloud',
      tech: 'Node.js • Express.js • AWS • Docker • GitHub Actions • JWT',
      description: 'Designed and deployed a cloud-native content management microservice with RESTful APIs for CRUD operations and format conversion. Supports JSON, Markdown, Text, and Image fragments with AWS S3, DynamoDB, and JWT authentication for secure, scalable handling.',
      links: [
        { text: 'Backend', url: 'https://github.com/KrissKapadia/fragments' },
        { text: 'Frontend', url: 'https://github.com/KrissKapadia/fragments-ui' }
      ]
    },
    {
      title: 'Hotel Kiosk Application',
      tech: 'Java • JavaFX • FXML • CSS • MVC',
      description: 'Developed a robust hotel management desktop application using Java and MVC architecture, featuring secure multi-user authentication, dynamic billing, and automated room management workflows. Designed a responsive interface with JavaFX, FXML, and custom CSS.',
      links: [
        { text: 'GitHub', url: 'https://github.com/KrissKapadia/HotelManagement' }
      ]
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
      }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        // eslint-disable-next-line react-hooks/exhaustive-deps
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const ExternalLinkIcon = () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
      <path d="M7 17l9.2-9.2M17 17V7M17 7H7"/>
    </svg>
  );

  return (
    <section id="projects" className="section projects-section" ref={sectionRef}>
      <div className="container">
        <h2 className="section-title">Featured Projects</h2>
        <div className="projects-grid">
          {projects.map((project, index) => (
            <div
              key={index}
              className={`project-card ${isVisible ? 'fade-in visible' : 'fade-in'}`}
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <div className="project-header">
                <h3>{project.title}</h3>
                <div className="project-tech">{project.tech}</div>
              </div>
              <div className="project-content">
                <div className="project-description">
                  {project.description}
                </div>
                <div className="project-links">
                  {project.links.map((link, linkIndex) => (
                    <a
                      key={linkIndex}
                      href={link.url}
                      className="project-link"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <span>{link.text}</span>
                      <ExternalLinkIcon />
                    </a>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;